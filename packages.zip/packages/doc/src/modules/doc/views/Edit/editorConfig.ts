import {Boot, IEditorConfig, IToolbarConfig, i18nGetResources} from '@wangeditor-next/editor';
// eslint-disable-next-line import/no-extraneous-dependencies
import {replaceBaseUrl} from '@/utils/request';
import {getTenant, getToken, message} from '@/utils/tools';
import {ItemDetail} from '../../entity';
import Inspect from './elements/Inspect';
import Line from './elements/Line';
import Review from './elements/Review';
import Variable from './elements/Variable';

const resources = i18nGetResources('zh-CN');
resources.justify.left = '居左对齐';
resources.justify.right = '居右对齐';
//console.log(resources);

export function getToolbarConfig(itemDetail: ItemDetail): Partial<IToolbarConfig> {
  return {
    //modalAppendToBody: true,
    toolbarKeys: [
      'headerSelect',
      'color',
      'bgColor',
      {
        key: 'group-more-style',
        title: '更多',
        iconSvg:
          '<svg viewBox="0 0 1024 1024"><path d="M707.872 484.64A254.88 254.88 0 0 0 768 320c0-141.152-114.848-256-256-256H192v896h384c141.152 0 256-114.848 256-256a256.096 256.096 0 0 0-124.128-219.36zM384 192h101.504c55.968 0 101.504 57.408 101.504 128s-45.536 128-101.504 128H384V192z m159.008 640H384v-256h159.008c58.464 0 106.016 57.408 106.016 128s-47.552 128-106.016 128z"></path></svg>',
        menuKeys: ['bold', 'underline', 'through', 'italic', 'sup', 'sub'], //, 'code'
      },
      '|',
      'fontSize',
      'fontFamily',
      'lineHeight',
      '|',
      {
        key: 'group-justify',
        title: '对齐',
        iconSvg:
          '<svg viewBox="0 0 1024 1024"><path d="M768 793.6v102.4H51.2v-102.4h716.8z m204.8-230.4v102.4H51.2v-102.4h921.6z m-204.8-230.4v102.4H51.2v-102.4h716.8zM972.8 102.4v102.4H51.2V102.4h921.6z"></path></svg>',
        menuKeys: ['justifyLeft', 'justifyRight', 'justifyCenter', 'justifyJustify'],
      },
      // {
      //   key: 'group-indent',
      //   title: '缩进',
      //   iconSvg:
      //     '<svg viewBox="0 0 1024 1024"><path d="M0 64h1024v128H0z m384 192h640v128H384z m0 192h640v128H384z m0 192h640v128H384zM0 832h1024v128H0z m0-128V320l256 192z"></path></svg>',
      //   menuKeys: ['indent', 'delIndent'],
      // },
      'bulletedList',
      'numberedList',
      '|',
      {
        key: 'group-image',
        title: '图片',
        iconSvg:
          '<svg viewBox="0 0 1024 1024"><path d="M959.877 128l0.123 0.123v767.775l-0.123 0.122H64.102l-0.122-0.122V128.123l0.122-0.123h895.775zM960 64H64C28.795 64 0 92.795 0 128v768c0 35.205 28.795 64 64 64h896c35.205 0 64-28.795 64-64V128c0-35.205-28.795-64-64-64zM832 288.01c0 53.023-42.988 96.01-96.01 96.01s-96.01-42.987-96.01-96.01S682.967 192 735.99 192 832 234.988 832 288.01zM896 832H128V704l224.01-384 256 320h64l224.01-192z"></path></svg>',
        menuKeys: ['insertImage', 'uploadImage'],
      },
      'insertLink',
      'insertTable',
      //'codeBlock',
      'line',
      '|',
      'formatPainter',
      'clearStyle',
      //'review',
      '|',
      'undo',
      'redo',
    ],
    // insertKeys: {
    //   index: 32,
    //   keys: ['_ai', '_outline'],
    // },
    // excludeKeys: ['fullScreen'],
  };
}
export const editorConfig: Partial<IEditorConfig> = {
  placeholder: '请输入内容...',
  scroll: false,
  // onBlur: (e) => {
  //   addClass(document.getElementById('_ai_button')!, 'disabled');
  // },
  // onFocus: (e) => {
  //   removeClass(document.getElementById('_ai_button')!, 'disabled');
  // },
  hoverbarKeys: {
    text: {
      menuKeys: [
        'ai',
        '|',
        'fontSize',
        'fontFamily',
        '|',
        'color',
        'bgColor',
        '|',
        'bold',
        'underline',
        'through',
        'italic',
        '|',
        'formatPainter',
        'clearStyle',
      ],
    },
    line: {
      menuKeys: ['lineColor', 'lineWeight'],
    },
    review: {
      match: (editor, node: any) => {
        if (node.type === 'review') {
          return node.source;
        }
        return false;
      },
      menuKeys: ['applyReplace', 'unReplace', 'reviewList'],
    },
  },
  MENU_CONF: {
    fontFamily: {
      fontFamilyList: [
        {name: '黑体', value: 'SimHei'},
        {name: '楷体', value: '楷体, 楷体-简, 楷体-繁, KaiTi, STKaiti, 华文楷体'},
        {name: '宋体', value: '宋体, 宋体-简, 宋体-繁, 华文宋体, simsun, SimSun, STSong'},
        {name: '仿宋', value: '仿宋, FangSong, STFangsong'},
        '微软雅黑',
        'Arial',
        'Arial Black',
        'Tahoma',
        'Verdana',
        {name: 'Times Roman', value: 'Times New Roman'},
        {name: 'Comic Sans', value: 'Comic Sans MS'},
        'Courier New',
      ],
    },
    fontSize: {
      fontSizeList: [
        {name: '‌初号‌', value: '56px'},
        {name: '‌小初', value: '48px'},
        {name: '‌一号‌', value: '34px'},
        {name: '小一', value: '32px'},
        {name: '‌二号‌', value: '29px'},
        {name: '‌小二', value: '24px'},
        {name: '三号', value: '21px'},
        {name: '‌小三', value: '20px'},
        {name: '‌四号‌', value: '18px'},
        {name: '‌小四‌', value: '16px'},
        {name: '‌五号‌', value: '14px'},
        {name: '‌小五‌', value: '12px'},
        {name: '‌六号‌', value: '10px'},
        {name: '小六‌', value: '8px'},
        {name: '‌七号‌', value: '7px'},
        {name: '‌八号‌', value: '6px'},
      ],
    },
    uploadImage: {
      base64LimitSize: 2 * 1024,
      fieldName: 'file',
      server: replaceBaseUrl('/dream/pen/upload/img'),
      timeout: 5 * 1000,
      maxFileSize: 10 * 1024 * 1024, // 10M
      // 将 meta 拼接到 url 参数中，默认 false
      metaWithUrl: false,
      headers: {
        Authorization: getToken(),
        Tenant: getTenant(),
      } as any,
      onSuccess(file: any, res: any) {
        //console.log(`${file.name} 上传成功`, res);
      },
      onFailed(file: any, res: any) {
        message.error('上传失败');
        //console.log(`${file.name} 上传失败`, res);
      },
      onError(file: any, err: any, res: any) {
        const request = err.request;
        message.error(request.status === 402 ? '上传失败: 租户已切换' : '上传失败');
        //console.log(`${file.name} 上传出错`, err, res);
      },
    },
  },
  // MENU_CONF: {
  //   fontSize: {
  //     title: 'sss',
  //   },
  // },
  // customPaste: (editor: IDomEditor, event: ClipboardEvent): boolean => {
  //   // event 是 ClipboardEvent 类型，可以拿到粘贴的数据
  //   // 可参考 https://developer.mozilla.org/zh-CN/docs/Web/API/ClipboardEvent

  //   const html = event.clipboardData!.getData('text/html'); // 获取粘贴的 html
  //   const text = event.clipboardData!.getData('text/plain'); // 获取粘贴的纯文本
  //   const rtf = event.clipboardData!.getData('text/rtf'); // 获取 rtf 数据（如从 word wsp 复制粘贴）

  //   console.log(html, text, rtf);

  //   // 同步
  //   editor.insertText('xxx');

  //   // 异步
  //   setTimeout(() => {
  //     editor.insertText('yy');
  //   }, 1000);

  //   // 阻止默认的粘贴行为
  //   event.preventDefault();
  //   return false;

  //   // 继续执行默认的粘贴行为
  //   // return true
  // },
};
// if ('queryLocalFonts' in window) {
//   (window as any).queryLocalFonts().then((items: any) => {
//     console.log(items);
//   });
// }

// Boot.registerRenderStyle((node, vnode) => {
//   if (!SlateText.isText(node)) {
//     return vnode;
//   }
//   const replace: string = (node as any).replace;
//   if (replace) {
//     if (!vnode.data!.props) {
//       vnode.data!.props = {};
//     }
//     vnode.data!.props.title = replace;
//     vnode.data!.props.className = `${vnode.data!.props.className || ''} w-e-replace`;
//   }
//   return vnode;
// });
// Boot.registerStyleToHtml((node, elemHtml: string) => {
//   if (!SlateText.isText(node)) {
//     return elemHtml;
//   }
//   const replace: string = (node as any).replace;
//   if (replace) {
//     return `<span data-replace="${replace}">${elemHtml}</span>`;
//   }
//   return elemHtml;
// });
// Boot.registerParseStyleHtml((elem, node, editor) => {
//   if (!SlateText.isText(node)) {
//     return node;
//   }
//   const replace = elem.getAttribute('data-replace');
//   if (replace) {
//     (node as any).replace = replace;
//   }
//   return node;
// });
Boot.registerModule(Review);
Boot.registerModule(Inspect);
Boot.registerModule(Variable);
Boot.registerModule(Line);

// ‌初号‌：42磅。
// ‌小初‌：36磅。
// ‌一号‌：26磅。
// ‌小一‌：24磅。
// ‌二号‌：22磅。
// ‌小二‌：18磅。
// ‌三号‌：16磅。
// ‌小三‌：15磅。
// ‌四号‌：14磅。
// ‌小四‌：12磅。
// ‌五号‌：10.5磅。
// ‌小五‌：9磅。
// ‌六号‌：7.5磅。
// ‌小六‌：6.5磅。
// ‌七号‌：5.5磅。
// ‌八号‌：5磅。‌‌
