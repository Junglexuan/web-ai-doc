import {DomEditor, IDomEditor, SlateElement} from '@wangeditor-next/editor';
// eslint-disable-next-line import/no-extraneous-dependencies
import {VNode, h} from 'snabbdom';
import {VariableElement} from './custom-types';

function renderElem(elem: SlateElement, children: VNode[] | null, editor: IDomEditor): VNode {
  const {info, field, editable} = elem as VariableElement;
  const selected = DomEditor.isNodeSelected(editor, elem);
  const vnode = h(
    'span',
    {
      props: {
        className: selected ? `w-e-variable on${editable ? ' editable' : ''}` : `w-e-variable${editable ? ' editable' : ''}`,
        contentEditable: false,
        title: info,
        lang: field,
      },
      on: {
        click(event) {
          const el = event.currentTarget as HTMLElement;
          if (window.getSelection()?.isCollapsed && !editor.getConfig().readOnly) {
            editor.emit('variable-selected', {elem, pos: el.getBoundingClientRect()});
          }
        },
      },
      //style: {display: 'inline-block', marginLeft: '3px'},
      // style: {
      //   marginLeft: '3px',
      //   marginRight: '3px',
      //   backgroundColor: 'var(--w-e-textarea-slight-bg-color)',
      //   border: selected // 选中/不选中，样式不一样
      //     ? '2px solid var(--w-e-textarea-selected-border-color)' // wangEditor 提供了 css var https://www.wangeditor.com/v5/theme.html
      //     : '2px solid transparent',
      //   borderRadius: '3px',
      //   padding: '0 3px',
      // },
    },
    children
    //[h('cite', {}, [title]), h('span', {}, [labels.join('')]), ...children!]
  );

  return vnode as any;
}

export default {
  type: 'variable',
  renderElem,
};
